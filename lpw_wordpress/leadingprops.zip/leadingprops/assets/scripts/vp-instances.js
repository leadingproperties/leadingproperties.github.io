(function($){


	/*var lpwGoogleMap = new window.lpw.Map(
		'http://localhost:8000/fixtures/geo-points-api.json',
		false,
		autoComplete
	);*/
})(jQuery);