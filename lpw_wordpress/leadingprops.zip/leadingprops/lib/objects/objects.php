<?php
require_once 'classes/LP_ObjectList.class.php';
require_once 'classes/LP_lang.class.php';
require_once 'classes/Tags.php';
require_once 'functions.php';