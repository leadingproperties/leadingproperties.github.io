<?php
require 'theme-update-checker.php';
$update = new ThemeUpdateChecker(
	'leadingprops',
	'http://lpwdev.com/lpw_wordpress/info.json'
);