<?php
get_template_part('templates/head');
get_header();
?>
<?php get_template_part('templates/content-single', get_post_type()); ?>

<?php
get_footer();