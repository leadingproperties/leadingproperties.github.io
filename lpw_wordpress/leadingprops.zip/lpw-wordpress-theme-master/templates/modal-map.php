<!-- Map Modal -->
<div id="map-modal" class="modal modal-large" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <button type="button" class="btn btn-close modal-close" data-dismiss="modal" aria-label="Close">Close</button>
            <div id="map-canvas" class="map-full"></div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->