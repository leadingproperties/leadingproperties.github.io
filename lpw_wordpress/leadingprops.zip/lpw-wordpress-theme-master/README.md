# lpw-wordpress-theme

## Installation

1. **Dashboard -> Pages**

- Create pages Sale/Rent/Sale Favorites/Rent favorites/Single object
- edit each pages and select appropriate template.

2. **Dashboard -> Options**

- **API**: Enter API key ( require on mylpw.io ) and URL (https://lpw-public-api.herokuapp.com/)
- **Pages**: assign pages to show rent/sale/favorites/etc.
- **Header**: Upload your logo (350x90), set phone and email to show in header.

3. **Dashboard -> Appearance -> Menus**

- Create new menu (Menu name: Top as example), and assign it to primary navigation.
- Then drag and drop pages you need to menu. _**NOTE**: Buy/Rent in meny by default, do not add them._
